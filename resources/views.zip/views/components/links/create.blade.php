<a href="{{ $href }}" class="btn btn-primary {{ $class ?? '' }}">{{ $label ??  __('create')  }}</a>
