<a href="{{ $href }}" class="btn btn-secondary {{ $class ?? '' }}">{{ $label ??  __('back')  }}</a>
