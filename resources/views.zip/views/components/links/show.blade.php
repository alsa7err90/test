<a href="{{ $href }}" class="btn btn-info {{ $class ?? '' }}">{{ $label ??  __('show')  }}</a>
