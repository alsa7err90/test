 @extends('layouts.app')

 @section('content')
     home
 @endsection
